/**
 * Main Class
 * @date 2018/1/13.
 */
public class NameOfMainClass {
    public static void main(String[] args) {
        SudoMainFrame mainFrame = new SudoMainFrame();
        mainFrame.setVisible(true);
    }
}
