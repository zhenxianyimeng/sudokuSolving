/**
 * Main Class
 * @date 2018/1/13.
 */
public class NameOfMainClass {
    public static void main(String[] args) {
        ShuduMainFrame mainFrame = new ShuduMainFrame();
        mainFrame.setVisible(true);
    }
}
